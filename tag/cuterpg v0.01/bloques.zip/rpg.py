import pygame
import images


class RPG:
    def __init__(self, surface, rpg_map, pars):
        self.rpgmap=__import__(rpg_map)
        self.pars=__import__(pars)
        self.surface=surface
        self.contador=0
        self.pos=self.rpgmap.posicion_inicial
        images.cacheImage('fondo')
        images.cacheImage('bar_izq')
        for elem in self.rpgmap.relacion:
            images.cacheImage(str(self.rpgmap.relacion[elem]))
            
        
    def new_event(self,event):
        if event.type == pygame.KEYDOWN:
            
            
            if pygame.key.name(event.key)=='up' and not self.pos[1]==0 and self.rpgmap.puede_estar(self.pos[0],self.pos[1]-1,1):
                self.pos[1]-=1
            elif pygame.key.name(event.key)=='down' and not self.pos[1]==len(self.rpgmap.capas[0])-1 and self.rpgmap.puede_estar(self.pos[0],self.pos[1]+1,1):
                self.pos[1]+=1
            elif pygame.key.name(event.key)=='left' and not self.pos[0]==0 and self.rpgmap.puede_estar(self.pos[0]-1,self.pos[1],1):
                self.pos[0]-=1
            elif pygame.key.name(event.key)=='right' and not self.pos[0]==(len(self.rpgmap.capas[0][0])-1) and self.rpgmap.puede_estar(self.pos[0]+1,self.pos[1],1):
                self.pos[0]+=1
                print "x"
            elif event.key == pygame.K_ESCAPE and self.contador==0:
                self.contador+=1
                return True
            else:
                print "--"
                return False
        
    def update(self):
        
        self.surface.fill((251,255,251))
        
        
        fondo=images.getImage('fondo')  
        fondo=pygame.transform.scale(fondo,( self.pars.SCREEN_WIDTH, fondo.get_height() ))
        self.surface.blit( fondo, (0,0, self.pars.SCREEN_WIDTH,  self.pars.SCREEN_HEIGHT ) )
        
        pos_personaje=[]
        pos_personaje.append(self.pars.pos_campo[0]+self.pos[0]*self.pars.TILE_WIDTH + self.pars.TILE_WIDTH/2)
        pos_personaje.append(self.pars.pos_campo[1]+self.pos[1]*self.pars.TILE_Y_SPACING-self.pars.TILE_DEPTH*self.pos[2] + self.pars.TILE_HEIGHT/2)
        
        
        for y in range(len(self.rpgmap.capas[0])):
            for z in range(len(self.rpgmap.capas)):
                for x in range(len(self.rpgmap.capas[1][y])):
                    if not self.rpgmap.capas[z][y][x] == 0:
                        #bloq = pygame.image.load("img/" + self.rpgmap.relacion [ self.rpgmap.capas[z][y][x] ]+".png")
                        bloq = images.getImage( self.rpgmap.relacion [ self.rpgmap.capas[z][y][x] ] )
                        posicion_bloque=[0,0]
                        posicion_bloque[0]=self.pars.pos_campo[0]+self.pars.TILE_WIDTH*x-pos_personaje[0]+self.pars.SCREEN_WIDTH/2
                        posicion_bloque[1]=self.pars.pos_campo[1]+self.pars.TILE_Y_SPACING*y-pos_personaje[1]+self.pars.SCREEN_HEIGHT/2-self.pars.TILE_DEPTH*z
                        
                        self.surface.blit(bloq,posicion_bloque)
                    
                    if self.pos == [x,y,z]:
                        pos_protagonista=(self.pars.SCREEN_WIDTH-self.pars.TILE_WIDTH)/2, (self.pars.SCREEN_HEIGHT-self.pars.TILE_HEIGHT)/2
                        #self.surface.blit(pygame.image.load("img/" + self.rpgmap.relacion['personaje'] + ".png").convert_alpha(),pos_protagonista)
                        self.surface.blit(images.getImage(self.rpgmap.relacion['personaje']),pos_protagonista)
        
        
        #fondo=pygame.image.load("img/bar_izq.png")
        fondo=images.getImage('bar_izq')
        fondo=pygame.transform.scale(fondo,( fondo.get_width() *  self.pars.SCREEN_WIDTH / self.pars.SCREEN_HEIGHT , self.pars.SCREEN_HEIGHT ))
        self.surface.blit( fondo, (0,0, self.pars.SCREEN_WIDTH,  self.pars.SCREEN_HEIGHT ) )

        
