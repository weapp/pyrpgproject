import pygame
from os import path

cache={}

def loadImage(name, colorkey=None):
    #fullname = path.dirname(__file__) + path.sep +'..' + path.sep + 'images' + path.sep + name + '.png'
    fullname = path.dirname(__file__) + path.sep + 'img' + path.sep + name + '.png'
    try:
        image = pygame.image.load(fullname)
    except pygame.error, message:
        print 'Cannot load image: ' + name
        raise SystemExit, message
    return image.convert_alpha()

def cacheImage(name):
    cache[name] = loadImage(name)
    
    
def getImage(name):
    return cache[name]
